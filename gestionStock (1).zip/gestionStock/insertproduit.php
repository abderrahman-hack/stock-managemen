<?php
session_start();
    
if(!isset($_SESSION['user'])) {
    header('location:index.php');
    exit();
}
    require_once("connexion.php");
    $ref=isset($_POST['reference'])?$_POST['reference']:null;
    $lib=isset($_POST['libelle'])?$_POST['libelle']:null;
    $prixA=isset($_POST['prixAchat'])?$_POST['prixAchat']:null;
    $prixV=isset($_POST['prixVente'])?$_POST['prixVente']:null;
    //$photo=isset($_POST['photo'])?$_POST['photo']:null;
    $cat=isset($_POST['cat'])?$_POST['cat']:null;
    $fourn=isset($_POST['idFourn'])?$_POST['idFourn']:null;
    
    $quantite=isset($_POST['quantity'])?$_POST['quantity']:null;
     echo $cat."<br>";
   

     $nom_photo= $_FILES['photo']['name'];
$image_tmp=$_FILES['photo']['tmp_name'];
move_uploaded_file($image_tmp,'images/'.$nom_photo);
  echo $quantite;
    $requete="insert into produit(reference,libelle,prixAchat,prixVente,photo,cat,fourn,quantity)
    values(?,?,?,?,?,?,?,?)";
    $params=array($ref,$lib,$prixA,$prixV,$nom_photo,$cat,$fourn,$quantite);

    $resultat=$pdo->prepare($requete);
    $etat = $resultat->execute($params);
    var_dump($etat);
    $requet="select idCAT from categorie";
    $resu=$pdo->query($requet);
    
    while($at = $resu->fetch()){
        $cate=$at['idCAT'];
        $categorie="update categorie
        set quatite=(select count(*) from produit where produit.cat='$cate')
        where idCAT='$cate' ";
        $result=$pdo->prepare($categorie);
        $eta = $result->execute();
    }
    $date= date("Y/m/d");
    


    $req="insert into approvisionnement(date_ach,id_fournisseur,product,quantite)
    values(?,?,?,?)";
    $param=array($date,$fourn,$lib,$quantite);

    $resul=$pdo->prepare($req);
    $etats = $resul->execute($param);
    var_dump($etats);
   header('location:products.php');


?>