<?php
 session_start();
    

    
 if(!isset($_SESSION['user'])) {
     header('location:index.php');
     exit();
 }
require_once("connexion.php");

$idPRO=isset($_POST['idPRO'])?$_POST['idPRO']:0 ;
$ref=isset($_POST['reference'])?$_POST['reference']:null;
$lib=isset($_POST['libelle'])?$_POST['libelle']:null;
$prixA=isset($_POST['prixAchat'])?$_POST['prixAchat']:null;
$prixV=isset($_POST['prixVente'])?$_POST['prixVente']:null;
$cat=isset($_POST['cat'])?$_POST['cat']:null;
$fourn=isset($_POST['idFourn'])?$_POST['idFourn']:null;
$quant=isset($_POST['quantity'])?$_POST['quantity']:null;


$nom_photo= $_FILES['photo']['name'];
$image_tmp=$_FILES['photo']['tmp_name'];
move_uploaded_file($image_tmp,'images/'.$nom_photo);
echo $idPRO." ".$ref." ".$lib. " ".$prixA. " ".$prixV. " ".$cat. " ".$fourn. " ";
echo $nom_photo. "<br>";

if(!empty($nom_photo)){
    $requete="update produit set reference=?,libelle=?,prixAchat=?,prixVente=?,photo=?,cat=?,fourn=?,quantity=? where idPRO=?";
    $params=array($ref,$lib,$prixA,$prixV,$nom_photo,$cat,$fourn,$quant,$idPRO);
}else{
    $requete="update produit set reference=?,libelle=?,prixAchat=?,prixVente=?,cat=?,fourn=?,quantity=? where idPRO=?";
    $params=array($ref,$lib,$prixA,$prixV,$cat,$fourn,$quant,$idPRO);
}

$resultat=$pdo->prepare($requete);
$etat=$resultat->execute($params);
var_dump($etat);

$requet="select idCAT from categorie";
$resu=$pdo->query($requet);
while($at = $resu->fetch()){
    $cate=$at['idCAT'];
    $categorie="update categorie
    set quatite=(select count(*) from produit where produit.cat='$cate')
    where idCAT='$cate' ";
    $result=$pdo->prepare($categorie);
    $eta = $result->execute();
}
header('location:products.php');



?>