<?php  
session_start();
if (isset($_SESSION['erreurLogin']))
    $erreurLogin = $_SESSION['erreurLogin'];
else {
    $erreurLogin = "";
}
session_destroy();
?>
<!doctype html>
<html lang="en">
  <head>
  	<title>Connecter</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/style (2).css">
	<style>
		div h2{
			font-family:'Franklin Gothic Medium', 'Arial Narrow', Arial, sans-serif;
		}
	</style>
	</head>
	<body>
		<section class="ftco-section">
		<div class="container">
			<div class="row justify-content-center">
				<div class="col-md-6 text-center mb-5">
					<h2 class="heading-section"><img src="images/bg-3.jpg" alt="logo" style="width:100px;height:100px;" ><i>GESTION DE STOCK</i></h2>
				</div>
			</div>
			<div class="row justify-content-center">
				<div class="col-md-7 col-lg-5">
					<div class="wrap">
						<div class="img" style="background-image: url(images/bg-2.jpg);"></div>
						<div class="login-wrap p-4 p-md-5">
			      	<div class="d-flex">
			      		<div class="w-100">
			      			<h3 class="mb-4">Se connecter</h3>
			      		</div>
								
			      	</div>
							<form method="post" action="seConnnecter.php" class="signin-form">
								
							<?php if (!empty($erreurLogin)) { ?>
                    			<div class="alert alert-danger">
                        			<?php echo $erreurLogin ?>
                    			</div>
               				 <?php } ?>
			      		<div class="form-group mt-3">
						  <label for="login">Login :</label>
                <input type="text" name="login" placeholder="Login"
                       class="form-control" autocomplete="off" required>
			    		</div>
		            	<div class="form-group">
						<label for="pwd">Mot de passe :</label>
              		  <input type="password" name="pwd"
                       placeholder="Mot de passe" class="form-control" required/>		            
							<span toggle="#password-field" class="fa fa-fw fa-eye field-icon toggle-password"></span>
		            	</div>
		            	<div class="form-group">
		            		<button type="submit" class="form-control btn btn-primary rounded submit px-3">
							<span class="glyphicon glyphicon-log-in"></span>
							Sign In</button>
		            	</div>
		            <div class="form-group d-md-flex">
		            	<div class="w-50 text-left">
			            	<label class="checkbox-wrap checkbox-primary mb-0">
									  <input type="checkbox" checked>
									  <span class="checkmark"></span>
										</label>
									</div>
									<div class="w-50 text-md-right">
										<a href="#"></a>
									</div>
		            </div>
		          </form>
		          <p class="text-center"><a data-toggle="tab" href="#signup">S'inscrir</a></p>
		        </div>
		      </div>
				</div>
			</div>
		</div>
	</section>
	
		
			
	

	<script src="js/jquery.min.js"></script>
  <script src="js/popper.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/main.js"></script>

	</body>
</html>

