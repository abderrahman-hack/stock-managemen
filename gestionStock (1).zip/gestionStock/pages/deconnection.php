<?php
    require_once("../connexion.php");

    $count="select count(*) countc from cart";
    $resCount=$pdo->query($count);
    $tabCount=$resCount->fetch();
    $nbr=$tabCount['countc'];
    var_dump($tabCount);

    if($nbr!=0)
    {
    
             $requete="DELETE from cart ";
            $resultat=$pdo->prepare($requete);
            $ana=$resultat->execute();
             var_dump($ana);
      
    header('location:../index.php');
   } else{

header('location:../index.php');
   }
?>