<?php
    session_start();
    if(!isset($_SESSION['user'])) {
        header('location:../index.php');
        exit();
    }
    require_once("../connexion.php");

    $id=isset($_GET['idCAT'])?$_GET['idCAT']:'all';
    $result="select * from produit ";
    
    $resultats=$pdo->query($result);
    
    $requeteCount="select count(*) countF from produit";
    $filCount=$pdo->query($requeteCount);
    $tabCount=$filCount->fetch();
    $nbrfil=$tabCount['countF'];

$requete="select idPRO,libelle, prixAchat,photo,quantity from categorie , produit where produit.cat=categorie.idCAT";
$result="select idCAT,lib from categorie ";
    $where_requete = "";
    if($id=='all')
    {   
    $resultatF=$pdo->query($requete);
    }
    else if($id) {
        $where_requete .= " and produit.cat ='$id'";
        $requete .= $where_requete;
    }
    $resultatF=$pdo->query($requete);
    $resultF=$pdo->query($result);
    /*$libelle=$produit['libelle'];
    $prixAchat=$produit['prixAchat'];
    $photo=$produit['photo'];*/
   
?>

<!DOCTYPE html>
<html>
    <head>
    <LInk rel="stylesheet" href="../css/bootstrap.min.css"></LInk>
    <link rel="stylesheet" href="../assets/demo.css">
    <link rel="stylesheet" href="../assets/navigation-icons.css">
    <link rel="stylesheet" href="../assets/slicknav/slicknav.min.css">
    
    <link rel="stylesheet" href="../assets/font-awesome.min.css">


    <style>
        {
            box-sizing: border-box;
        }
        /* Set additional styling options for the columns*/
        .column {
        float: left;
        width: 50%;
        }

        .row:after {
        content: "";
        display: table;
        clear: both;
        }
    </style>
        <link rel="shortcut icon" href="img/lifestyleStore.png" />
        <title>product </title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <!-- latest compiled and minified CSS -->
        <link rel="stylesheet" href="../css/bootstrap.min.css" type="text/css">
        <!-- jquery library -->
        <script type="text/javascript" src="../js/jquery-3.2.1.min.js"></script>
        <!-- Latest compiled and minified javascript -->
        <script type="text/javascript" src="../js/bootstrap.min.js"></script>
        <!-- External CSS -->
        <link rel="stylesheet" href="../css/style (4).css" type="text/css">
        <style>
            .column {
                float: left;
                width: 33.33%;
                }
        </style>
    </head>
    <body>
    <nav class="menu-navigation-icons">
    <a href="acceuil.php" class="menu-yellow"><i class="glyphicon glyphicon-th-list"></i><span>Categories</span></a>
    <a href="products.php" class="menu-green"><i class="glyphicon glyphicon-shopping-cart"></i><span>les produits</span></a>
    <a href="../ticket/cart.php" class="menu-blue"><i class="glyphicon glyphicon-open-file"></i><span>Facture</span></a>
    <a href="password.php" class="menu-green"><i class="glyphicon glyphicon-lock"></i><span>editer mot de pass</span></a>
   
    <a onclick="return confirm('etes vous sur de vouloir deconnecter ?')" href="deconnection.php" class="menu-red"><i class="glyphicon glyphicon-log-out"></i><span>Deconnecter</span></a>
    
</nav>   <div>
        <div>
            <div class="container">
                <div class="jumbotron">
                    <h1>Bienvenue dans notre magasin!</h1>
                    <p>Nous avons les meilleurs appareils photo, ordinateurs portables et iphone pour vous. Pas besoin de chasser, nous avons tous au même endroit.</p>
                </div>
            </div>
        </div>
        </div>


        <div class="row">     
            <div>
                <div class="panel panel-info ">
                    
                <div class="panel-heading" style="font-size: 1.5em;padding: 1rem;text-align: center;text-transform: uppercase;">
                
                    <form method="get" action="products.php" class="form-inline">
                        <div class="container">
                            <div class="row"> 
                                <div class="column"><strong> Produits :</strong></div> 
                                    <div class="column">
                                            <select name="idCAT" class="form-control" id="idCAt" onchange="this.form.submit()" style="width:100%">
                                            <option value="all" <?php if($id==="all") echo "selected" ?>>tous les produits</option>
                                                <?php while($categorie=$resultF->fetch()){ ?>
                                                    <option value="<?php echo $categorie['idCAT'] ?>" 
                                                    <?php if($id===$categorie['idCAT']) echo "selected" ?>>
                                                    <?php echo $categorie['lib'] ?>
                                                    </option>
                                                <?php }?>
                                            </select>
                                    
                                    </div>
                                    <div class="column">
                                            <button type="submit" class="btn btn-success btn-lg" style="width:95%">
                                                <span class="glyphicon glyphicon-search"></span>
                                                Rechecher
                                            </button>
                                        
                                    </div>
                                                    
                            </div>

                                    <!------------------->
                                    
                        </div>   
                    </form>
                </div>

                            <table class="table table-striped table-bordered">
                                <thead>
                                    <tr class="danger">
                                    </tr>
                                </thead>
                                <tbody>
                                    <style>
                                        tbody {
                                                font-weight: bolder
                                            }
                                    </style>
                                        <?php while($produit=$resultatF->fetch()) { ?>
                                                <tr class="success"> 
                                                   <?php $idPRO=$produit['idPRO'] ;$quant=$produit['quantity']?> 
                                                   <?php 
                                                       if($quant!= 0){ ?>

                                                   <form action="../ticket/cart_add.php?idPRO=<?php echo $idPRO?>" method="GET">
                                                   <td> <input type="hidden" name="idPRO" class="form-control" value="<?php echo $idPRO ?>">
                        </td>
                                                    <td><img src="../images/<?php echo $produit['photo']?>">
                                                        </td> 
                                                    <td><?php echo $produit['libelle'] ?></td>
                                                    <td><?php echo $produit['prixAchat']. " DHS"?></td>
                                                       
                                                           <td> 
                       <input type="number" name="quantity" min=1 max=<?php echo $quant ?> >
                                                    </td>

                                                    <td>
                                                        <a href="../ticket/cart_add.php?idPRO=<?php echo $produit['idPRO']?>">
                                                            <button  class="btn btn-success btn-lg" type="submit" style="width:90%;">
                                                                <span class="glyphicon glyphicon-plus"></span>
                                                                ajouter au cart
                                                                    
                                                            </button>
                                                        </a> </td> </form>
                                                </tr>
                                                <?php }else{?>
                                                    <td> <input type="hidden" name="idPRO" class="form-control" value="<?php echo $idPRO ?>">
                        </td>
                                                    <td><img src="../images/<?php echo $produit['photo']?>">
                                                        </td> 
                                                    <td><?php echo $produit['libelle'] ?></td>
                                                    <td><?php echo $produit['prixAchat']. " DHS"?></td>
                                                       
                                                           <td> 
                                                               ce produit est epuise
                                                    </td>

                                                <?php } ?> 
                                            <?php  } ?>  
                                </tbody>
                            
                            </table> 
                        </div>
                 </div>
            </div>                                   

        </div>

    

            <br><br><br><br><br><br><br><br>
           <footer class="footer">
               <div class="container">
               
               </div>
           </footer>
       
        
    </body>
</html>
