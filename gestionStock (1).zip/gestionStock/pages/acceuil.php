<?php
 session_start();
 if(!isset($_SESSION['user'])) {
     header('location:../index.php');
     exit();
 }
    require_once("../connexion.php");
    $resu="select * from produit ";
    $resultatFi=$pdo->query($resu);
    $produit=$resultatFi->fetch();

    $requeteCount="select count(*) countF from produit";
    $filCount=$pdo->query($requeteCount);
    $tabCount=$filCount->fetch();
    $nbrfil=$tabCount['countF'];
    

    $categ="select * from categorie";
    $resultat=$pdo->query($categ);
   
    
?>
<!DOCTYPE html>
<html>

<head>
<head>
    <LInk rel="stylesheet" href="../css/bootstrap.min.css"></LInk>
    <link rel="stylesheet" href="../assets/demo.css">
    <link rel="stylesheet" href="../assets/navigation-icons.css">
    <link rel="stylesheet" href="../assets/slicknav/slicknav.min.css">
    <link rel="stylesheet" href="../assets/font-awesome.min.css">


    <style>
        {
            box-sizing: border-box;
        }
        /* Set additional styling options for the columns*/
        .column {
        float: left;
        width: 50%;
        }

        .row:after {
        content: "";
        display: table;
        clear: both;
        }
    </style>
        <link rel="shortcut icon" href="img/lifestyleStore.png" />
        <title>product </title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <!-- latest compiled and minified CSS -->
        <link rel="stylesheet" href="../css/bootstrap.min.css" type="text/css">
        <!-- jquery library -->
        <script type="text/javascript" src="../js/jquery-3.2.1.min.js"></script>
        <!-- Latest compiled and minified javascript -->
        <script type="text/javascript" src="../js/bootstrap.min.js"></script>
        <!-- External CSS -->
        <link rel="stylesheet" href="../css/style (4).css" type="text/css">
        
</head>

<body>
<nav class="menu-navigation-icons">
    <a href="acceuil.php" class="menu-yellow"><i class="glyphicon glyphicon-th-list"></i><span>Categories</span></a>
    <a href="products.php" class="menu-green"><i class="glyphicon glyphicon-shopping-cart"></i><span>les produits</span></a>
    <a href="../ticket/cart.php" class="menu-blue"><i class="glyphicon glyphicon-open-file"></i><span>Facture</span></a>
    <a href="password.php" class="menu-green"><i class="glyphicon glyphicon-lock"></i><span>editer mot de pass</span></a>
   
    <a onclick="return confirm('etes vous sur de vouloir deconnecter ?')" href="deconnection.php" class="menu-red"><i class="glyphicon glyphicon-log-out"></i><span>Deconnecter</span></a>
    
</nav>
<br>
        
            <div class="panel panel-info ">
                    <div class="panel-heading" style="color: blue;font-size: 1.5em;padding: 1rem;text-align: center;text-transform: uppercase;"><strong>top produits :</strong></div>
                    
                        <table class="table table-striped table-bordered">
                            <thead>
                            </thead>
                            <tbody>
                                <style>
                                    tbody {
                                            font-weight: bolder
                                        }
                                    </style>
                                <?php if( $nbrfil > 0 ) { ?>
                                    <?php while($produit=$resultatFi->fetch()){ ?>
                                        <?php if($produit['prixAchat'] > 10000.0) { ?>
                                          <tr class="success">
                                           <td><?php echo $produit['libelle'] ?></td>
                                            <td>
                                                <img src="../images/<?php echo $produit['photo']?>"
                                                    width="50px" height="50px" class="img-circle">
                                            </td>
                                            <td><?php echo $produit['prixAchat']. " DHS"?></td>
                                          </tr>
                                        <?php    }?>
                                     <?php    }?>
                                <?php } else { ?>
                                    <tr>
                                        <td>
                                            Aucune résultat
                                        </td>
                                    </tr>
                                <?php } ?>
                            </tbody>
                        
                        </table>
                    </div>
            </div>
       




      

            <div class="panel panel-info ">
                    <div class="panel-body">
                        <table class="table table-striped table-bordered">
                            <thead>
                            </thead>
                            <tbody>
                                <style>
                                    tbody {
                                            font-weight: bolder
                                        }
                                </style>
                                    
                            <tr style="text-align:center;">
                                <?php while($categorie=$resultat->fetch()){ ?>
                                    <td> 
                                        <a href="products.php?idCAT=<?php echo $categorie['idCAT']?>">
                                        <img src="../images/<?php echo $categorie['pic']?>"></a>
                                        <div class="caption">  
                                            <p id="autoResize"><?php echo $categorie['lib']."s"?></p>
                                            <p>Notre exquise collection des <?php echo $categorie['lib']."s"?>.</p>
                                        </div>
                                    </td> 
                                                  
                                <?php    }?>    
                                            
                            </tr>   
                            </tbody>
                        </table>
                    </div>
            </div>
 
      
           <br><br> <br><br><br><br>
           <footer class="footer"> 
               <div class="container">
               <center>
                  
               </center>
               </div>
           </footer>

        <script src="http://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<script src="assets/slicknav/jquery.slicknav.min.js"></script>
<script>
    $(function(){
        $('.menu-navigation-icons').slicknav();
    });
</script>

</body>

</html>
