<?php
session_start();
    
if(!isset($_SESSION['user'])) {
    header('location:index.php');
    exit();
}
    require_once("connexion.php");
    $login=isset($_POST['login'])?$_POST['login']:null;
    $email=isset($_POST['email'])?$_POST['email']:null;
    $role=isset($_POST['role'])?$_POST['role']:"V";
    $etat=isset($_POST['etat'])?$_POST['etat']:null;
    
    $adresse=isset($_POST['adresse'])?$_POST['adresse']:null;
   
    $numTele=isset($_POST['numTele'])?$_POST['numTele']:null;
   
   
    $pwd=isset($_POST['password'])?$_POST['password']:null;
    echo $login." ...".$email."...".$role." ......".$etat."....".$adresse."...".$numTele."..." .$pwd;
    $requete="insert into utilisateur(login,email,role,etat,pwd,adresse,numTele)
    values(?,?,?,?,?,?,?)";
    $params=array($login,$email,$role,$etat,md5($pwd),$adresse,$numTele);

    $resultat=$pdo->prepare($requete);
    $etatx = $resultat->execute($params);
  
   header('location:utilisateur.php');


?>