<?php
    require_once("connexion.php");
    
    $id=isset($_GET['iduser'])?$_GET['iduser']:null;
    
    $requete="DELETE from utilisateur where iduser=?";
    $params=array($id);
 
    $resultat=$pdo->prepare($requete);
    $ana=$resultat->execute($params);

    header('location:utilisateur.php');


?>