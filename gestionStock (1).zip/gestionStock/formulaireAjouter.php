<?php
session_start();
    
if(!isset($_SESSION['user'])) {
    header('location:index.php');
    exit();
}
    require_once("connexion.php");

    $cat="select idCAT,lib from categorie ";
    $fourn="select * from fournisseur ";
   
    $resultF=$pdo->query($cat);
    $result=$pdo->query($fourn);
 
    
 
    
    
    ?>

<!DOCTYPE HTML>
<HTML>
    <Head>
        <meta charset="utf-8">
        <title>Nouveau produit</title>
        <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
         <link rel="stylesheet" type="text/css" href="css/style.css">

    </Head>
    <body>
      
       <div class="container">
            
            <div class="panel panel-primary margetop">
                <div class="panel-heading">L'ajout du produit</div>
                <div class="panel-body">
                    <form method="post" action="insertproduit.php" class="form" enctype="multipart/form-data">
                        <!-- ............ -->
                          <div class="form-row">
                              <div class="form-group col-md-6">
                                <label for="libelle">libelle :</label>
                                <input type="text" name="libelle" placeholder="libelle" class="form-control" required >
                              </div>
                              <div class="form-group col-md-6">
                                <label for="reference"> reference </label>
                                <input type="text" name="reference" placeholder="reference" class="form-control" required>
                              </div>
                          </div>
                        <div class="form-row">
                        <div class="form-group col-md-6">
                                <label for="photo">Photo :</label>
                                <input type="file" name="photo" />
                            </div>

                            <div class="form-group col-md-6">
                                <label for="cat">categorie</label>
                                <select name="cat" class="form-control" id="cat">
                                        <?php 
                                            while($_ENT=$resultF->fetch()){ ?>
                                                <option value="<?php echo $_ENT['idCAT'] ?>">
                                                <?php echo $_ENT['lib'] ?>
                                                </option>
                                        <?php }?>


                                </select>
                            </div>
                         </div>
            <!-- ............ -->  
                        <div class="form-row">
                            <div class="form-group col-md-6">
                               <label for="prixAchat">prix Achat :</label>
                                <input type="text" name="prixAchat" placeholder="prixAchat" class="form-control" required>
                            </div>
                            <div class="form-group col-md-6">
                               <label for="prixVente">prix vente :</label>
                                <input type="text" name="prixVente" placeholder="prixVente" class="form-control" required>
                            </div>

                        </div>
                     
                        <!-- ............ -->
             
                        <div class="form-row">
                        <div class="form-group col-md-6">
                        <label for="idFourn">fournisseur</label>
                                <select name="idFourn" class="form-control" id="idFourn">
                                        <?php 
                                            while($ENT=$result->fetch()){ ?>
                                                <option value="<?php echo $ENT['idFourn'] ?>">
                                                <?php echo $ENT['nomFourn'] ?>
                                                </option>
                                        <?php }?>


                                </select> </div>

                            <div class="form-group col-md-6">
                               
                            <label for="quantity">quantite :</label>
                                <input type="number" name="quantity" placeholder="quantity" class="form-control" min=1 max=10 required>
                           
                            </div>
                         </div>
                        <button type="submit" class="btn btn-success">
                            <span class="glyphicon glyphicon-save"></span>
                            
                            Enregistrer
                            
                        </button>
                        
                    </form>
                </div>
            </div>
        </div>
    </body>
</HTML>