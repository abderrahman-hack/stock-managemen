<?php
session_start();
    
if(!isset($_SESSION['user'])) {
    header('location:index.php');
    exit();
}
    require_once("connexion.php");

     
    $iduser=isset($_GET['idFourn'])?$_GET['idFourn']:null ;
  

    $result="select * from fournisseur,etat where idFourn=$iduser";

    $resultats=$pdo->query($result);
    $user=$resultats->fetch();

    $nom=$user['nomFourn'];
    $email=$user['emailFourn'];
   $adresse=$user['adresseFourn'];
    $numtele=$user['numTeleFourn'];
    
    ?>

<!DOCTYPE HTML>
<HTML>
    <Head>
        <meta charset="utf-8">
        <title>editer fourniseur</title>
        <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
         <link rel="stylesheet" type="text/css" href="css/style.css">

    </Head>
    <body>
      
       <div class="container">
            
            <div class="panel panel-primary margetop">
                <div class="panel-heading">Editer</div>
                <div class="panel-body">
                    <form method="post" action="editerfournisseur.php" class="form">
                        <!-- ............ -->
                        <div class="form-row">
                            <div class="form-group col-md-6">
                                <label for="idFourn">id : <?php echo $iduser ?></label>
                                <input type="hidden" name="idFourn" class="form-control" value="<?php echo $iduser ?>">
                        
                            </div>
                            <div class="form-group col-md-6">
                            <label for="nomFourn"> nom </label>
                                <input type="text" name="nomFourn" class="form-control" value="<?php echo $nom ?>"/>
                             </div>
                        </div>
                    
                        <div class="form-row">
                            <div class="form-group col-md-6">
                            <label for="adresseFourn"> Adresse</label>
                                <input type="text" name="adresseFourn" class="form-control"  value="<?php echo $adresse ?>"/>
                            
                            </div>
                            <div class="form-group col-md-6">
                                <label for="numTeleFourn">numero</label>
                                <input type="text" name="numTeleFourn" class="form-control"  value="<?php echo $numtele ?>"/>
                           
                            </div>
                        </div
                       
            <!-- ............ -->  
                        <div class="form-row">
                            <div class="form-group col-md-6">
                            <label for="emailFourn">email</label>
                                <input type="text" name="emailFourn" class="form-control"  value="<?php echo $email ?>"/>
                           
                           
                            </div>
                            <div class="form-group col-md-6">
                                <button type="submit" class="btn btn-success">
                                    <span class="glyphicon glyphicon-save"></span>
                                Enregistrer
                                </button>
                            </div>
                        </div>   
                          
                    </form>
                </div>
            </div>
        </div>
    </body>
</HTML>