<?php
session_start();
    
if(!isset($_SESSION['user'])) {
    header('location:index.php');
    exit();
}
    require_once("connexion.php");
    
    $id=isset($_GET['idCAT'])?$_GET['idCAT']:null;
  

    
    $requete="DELETE from categorie where idCAT=?";
    $params=array($id);
 
   
    $impossible="select count(*) countfourn from produit where cat =$id ";
    
    $resultatIMP=$pdo->query($impossible);
    $stag=$resultatIMP->fetch();
    $nbrfourn=$stag['countfourn'];

    if($nbrfourn==0){
        $params=array($id);
        $resultat=$pdo->prepare($requete);
        $ana=$resultat->execute($params);
        header('location:acceuil.php');
    }else{
        $message="impossible de supprimer cette categorie :supprimer d'abords les produits ";
        header("location:message2.php?msg=$message");
    }
    

?>