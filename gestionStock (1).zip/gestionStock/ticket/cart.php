<?php
    session_start();
    require '../connexion.php';
    $final="select idPRO,libelle,prixAchat,idCAT,quant from produit, cart ,categorie
    where categorie.idCAT=produit.cat and produit.idPRO=cart.PRO; ";
   
    $products= $pdo->query($final);
    $row=$products->fetch();
  

    $count="SELECT COUNT(*) AS rowcount FROM produit,cart where produit.idPRO=cart.PRO";
    $producs=$pdo->query($count);
    $number=$producs->fetch();

    $sum=0.0;
   
    /* 
    if($number!=0){
        while($row=$products->fetch()){
            echo $row['prixAchat']." ";
            $sum=$sum+$row['prixAchat'];

             
       }
      echo $sum;  
   
    }else{
        echo "Add items to cart first.";
    }
    */
  
?>
<!DOCTYPE html>
<html>
    <head>
        <link rel="shortcut icon" href="img/lifestyleStore.png" />
        <title>ticket</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <!-- latest compiled and minified CSS -->
        <link rel="stylesheet" href="../css/bootstrap.min.css" type="text/css">
        <!-- jquery library -->
        <script type="text/javascript" src="../js/jquery-3.6.0.min.js"></script>
        <!-- Latest compiled and minified javascript -->
        <script type="text/javascript" src="../js/bootstrap.min.js"></script>
        <!-- External CSS -->
        <link rel="stylesheet" href="../css/style.css" type="text/css">
    </head>
    <body>
    <body>
        <div>
            
            <br>
            <form action="" method="get">
            <div class="container">
                        <div class="panel panel-info ">
                            <table class="table table-striped table-bordered">
                                <tbody>
                                    <tr>
                                        <th>Item Number</th><th>Item Name</th><th>quantite</th><th>Price</th><th>
                                        <form action="" method="GET">
                                        </form>
                                        </th>
                                    </tr>
                                <?php 
                                        $products=$pdo->query($final);
                                        $counter=1;
                                        while($row=$products->fetch()) {  
                                            $id=$row['idPRO'] ;
                                            $idCAT=$row['idCAT'] ;
                                            $prix=$row['prixAchat'];
                                            $quantite=$row['quant'];

                                            $soustraction="update produit set quantity =(quantity - '$quantite') where idPRO ='$id'";
                                            $test=$pdo->query($soustraction);
                                            $produit=$test->fetch();
                                    ?>
                                    <tr>
                                        <th><?php echo $counter ?></th><th><?php echo $row['libelle']?></th><th><?php echo $row['quant']?></th><th><?php $price=$prix * $quantite;echo $price." DHS" ;$sum=$sum+$price;?></th>
                                        <th><a href="cart_remove.php?idPRO=<?php echo $row['idPRO'] ?>">Remove</a></th>
                                    </tr>
                                <?php $counter=$counter+1; }?>
                                    <tr >
                                        <th></th><th class="danger">Total</th>
                                        <th class="danger">
                                            <?php echo $sum." DHS"?>
                                        </th>
                                        <th>
                                            <a href="success.php?idPRO=<?php echo $id?>&idCAT=<?php echo $idCAT?>" class="btn btn-primary">Confirm Order</a>
                                            &nbsp 
                                            <a href="../pages/products.php" class="btn btn-primary">
                                                <span class="glyphicon glyphicon-backward" style="color:white"></span> retour
                                            </a>
                                        </th>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
               
            </div>
           </form>
           
           <div class="container ">
            <div class="panel panel-success margetop">
                <div class="panel-heading"></div>
                <div class="panel-body">
                    <h3 style="text-align:center;color:red;font-weight: bold;">
           si vous n'allez pas acheter ces articles, veuillez les supprimer du tableau
</h3>
                    
                
                      

                    

                </div>
            </div>
            
           
                </div>


            


            <br><br><br><br><br><br><br><br><br><br>
            <footer class="footer">
               <div class="container">
               </div>
           </footer>
        </div>
    </body>
</html>
