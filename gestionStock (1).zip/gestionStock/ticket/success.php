<?php
    session_start();
    require_once("../connexion.php");
    require('fpdf.php');
    require("fonctions.php");
    
   
   $date= date("Y/m/d");
        $id=isset($_GET['idPRO'])?$_GET['idPRO']:null;
        $iduser=$_SESSION['user']['login'];
    
  

        $idcat=$_GET['idCAT'];
        $requete="select idPRO,libelle,prixAchat,quant from produit,cart where produit.idPRO=cart.PRO";
        $cart = $pdo->query($requete);

        
        
while($prod=$cart->fetch()){
    
    $user="select iduser from utilisateur where login='$iduser'";
    $h=$pdo->query($user);
    $table=$h->fetch();
    $idUS=$table['iduser'];

    $table_vente="insert into vente(idProduit,idUS,dateShop,quanti)
    values(?,?,?,?)";
    $idProduit=$prod['idPRO'];
    $quantite=$prod['quant'];
    $params=array($idProduit,$idUS,$date,$quantite);
    $carte=$pdo->prepare($table_vente);
    $yes=$carte->execute($params);
    
}

      
 /* 
        $confirm_query="delete from cart  where PRO=$prod_id";
        $result=$pdo->prepare($confirm_query);
        $a=$result->execute();
        var_dump();
    */
?>

<!DOCTYPE html>
<html>
    <head>
        <link rel="shortcut icon" href="img/lifestyleStore.png" />
        <title>confirmation</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <!-- latest compiled and minified CSS -->
        <link rel="stylesheet" href="../css/bootstrap.min.css" type="text/css">
        <!-- jquery library -->
        <script type="text/javascript" src="../js/jquery-3.6.0.min.js"></script>
        <!-- Latest compiled and minified javascript -->
        <script type="text/javascript" src="../js/bootstrap.min.js"></script>
        <!-- External CSS -->
        <link rel="stylesheet" href="../css/style.css" type="text/css">
    </head>
    <body>
        
           
            <br> <br> <br> <br> <br> <br>
            <div class="container">
                <div class="panel panel-primary">
                <div class="panel-heading"></div>
                <div class="panel-body">
                    <form action="" method="POST">   
                            <p>la commande est confirmée . <a href="ticket.php?iduser=<?php echo $iduser?>&idPRO=<?php echo $id?>">Cliquez ici</a> pour voir votre billet.</p>
                            <p><a href="../pages/products.php">retour</a></p>
                        </div>
                    </div>
                    </form>
                </div>
            </div>
            <footer class="footer">
               <div class="container">
                <center>
                 
               </center>
               </div>
           </footer>
    
    </body>
</html>
