<?php
session_start();
	
require('../connexion.php');
require("fonctions.php");

//$pdo = new PDO("mysql:host=localhost;dbname=ecoledb", "root", "");



$iduser=$_SESSION['user']['login'];
    
    

$idPRO=isset($_POST['idPRO'])?$_POST['idPRO']:null;

echo $iduser."<br>";
$requete="select libelle,prixAchat,quant from produit,cart where produit.idPRO=cart.PRO";
$cart = $pdo->query($requete);
$identite_utilisateur = $pdo->query("SELECT * FROM utilisateur WHERE login='$iduser'");

$utlisateur = $identite_utilisateur->fetch();

$nom = strtoupper($utlisateur['login']);

$email = strtoupper($utlisateur['email']);

$adresse = strtoupper($utlisateur['adresse']);

$num = strtoupper("0".$utlisateur['numTele']);



$products = $pdo->query("SELECT  libelle,prixAchat ,quant
                                    from produit, cart 
                                    where produit.idPRO=cart.PRO ");
$produit = $products->fetch();

$libelle = strtoupper($produit['libelle']);

$prixAchat = strtoupper($produit['prixAchat']);

$quantity = strtoupper($produit['quant']);


require('fpdf.php');

//Création d'un nouveau doc pdf (Portrait, en mm , taille A5)
$pdf = new FPDF('P', 'mm', 'A2');

//Ajouter une nouvelle page
$pdf->AddPage();

// entete
$pdf->Image('../images/Abderrahman.png', 170, 5, 80, 20);

// Saut de ligne
$pdf->Ln(18);


// Police Arial gras 16
$pdf->SetFont('Arial', 'B', 16);

// Titre
//$pdf->Cell(0, 10, '', 'TB', 1, 'C');
$pdf->Cell(160);
$pdf->Cell(80, 5, 'TICKET ', 'LRB', 1, 'C');

// Saut de ligne
$pdf->Ln(5);

// Début en police Arial normale taille 10

$pdf->SetFont('Arial', '', 10);
$h = 7;
$retrait = "                                                                                                                                                                   ";
$retrait2= "                                                                                                                                                                               ";
$retrait3="     ";

$pdf->Write($h, $retrait . "Le client : ");

//Ecriture en Gras-Italique-Souligné(U)
$pdf->SetFont('', 'BIU');
$pdf->Write($h, $nom . "\n");

//Ecriture normal
$pdf->SetFont('', '');

$pdf->Write($h, $retrait . "d'email : " . $email .  "\n");
$pdf->Write($h, $retrait ."habite à : " . $adresse . " \n");

$pdf->Write($h, $retrait . "Tel : " . $num . " \n");

$pdf->Write($h, $retrait . "         - - - - - - - - - - - - - - - - - - - - - - - - - - - - - \n");


$pdf->Write($h, $retrait . "Produits acheté  :   \n");

$sum=0.0;
while($prod=$cart->fetch()){
    $price=$prod['prixAchat'];
    $quant=$prod['quant'];
    $sum=$sum+($quant * $price);
    $pdf->Write($h, $retrait2  . $quant." x ".$prod['libelle']. $retrait3 .$quant * $price." DHS" . " \n");
}
$pdf->Write($h, $retrait . "         - - - - - - - - - - - - - - - - - - - - - - - - - - - - - \n");


echo "\n";
$pdf->Write($h, $retrait . "TOTAL :  " . $sum . " DHS"."  \n");


$pdf->Write($h,  $retrait ." ***** nous vous souhaitons un bon journée ***** \n");

$date=$pdf->Cell(0, 5, $retrait3.'      Fait à SAFI Le :' . date('d/m/Y'), 0, 1, 'C');


// Décalage de 150 mm à droite
$pdf->Cell(160);
$pdf->Cell(80, 5, ' ', 'LR', 1, 'C');
$pdf->Cell(160);
$pdf->Cell(80, 5, ' ', 'LR', 1, 'C'); // LR Left-Right
$pdf->Cell(160);
$pdf->Cell(80, 5, "Mr Aberrahman", 'LR', 1, 'C');
$pdf->Cell(160);
$pdf->Cell(80, 5, ' ', 'LR', 1, 'C');
$pdf->Cell(160);
$pdf->Cell(80, 5, ' ', 'LRB', 1, 'C'); // LRB : Left-Right-Bottom (Bas)

//Afficher le pdf
$pdf->Output('', '', true);

while($prod=$cart->fetch()){
    $table_vente="insert into vente(idProduit,idUS,dateShop)
values(?,?,?)";
    $idProduit=$prod['idPRO'];
    $params=array($idPRO,$user,$date);
    $carte=$pdo->prepare($table_vente);
    $yes=$carte->execute($params);
}


?>