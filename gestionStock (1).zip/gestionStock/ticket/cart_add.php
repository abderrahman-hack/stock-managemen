<?php
    require '../connexion.php';
    session_start();
    $user_id=$_SESSION['user']['login'];
    $item_id=isset($_GET['idPRO'])?$_GET['idPRO']:0;
    
    $quant=isset($_GET['quantity'])?$_GET['quantity']:1;
   echo "user id : ".$user_id."..... quant : ".$quant.".... produit : ".$item_id;

    //echo "id user : ".$user_id." ".$user."<br> id produit : ".$item_id;
    $added="Added to cart";
    //echo $added;
    $add_to_cart_query="insert into cart(username,PRO,quant,status) values (?,?,?,?)";
    $params=array($user_id,$item_id,$quant,$added);
    $add_to_cart_result=$pdo->prepare($add_to_cart_query);
    $ana=$add_to_cart_result->execute($params);
   
    /*$add_to_cart_result=$pdo->query($add_to_cart_query);
    $added=$add_to_cart_result->fetch();*/
   header('location:../pages/products.php');
?>