<?php
    require '../connexion.php';
    session_start();
    $item_id=$_GET['idPRO'];
    $delete_query="delete from cart where PRO=?";
    $params=array($item_id) ;
    $resultat=$pdo->prepare($delete_query);
    $ana=$resultat->execute($params);

    header('location: cart.php');
?>