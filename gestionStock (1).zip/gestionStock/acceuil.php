<?php
 session_start();
    
 if(!isset($_SESSION['user'])) {
     header('location:index.php');
     exit();
 }
    require_once("connexion.php");
    $resu="select * from produit ,categorie where produit.cat=categorie.idCAT";
    $resultatFi=$pdo->query($resu);
    $requeteCount="select count(*) countF from produit";
    $categorie="select * from categorie";
   
    $categ=$pdo->query($categorie);
    $tab=$categ->fetch();
    $cat=$tab['idCAT'];
    $filCount=$pdo->query($requeteCount);
    $tabCount=$filCount->fetch();
    $nbrfil=$tabCount['countF'];


      
    
    $categ="select * from categorie";
    
    $resultat=$pdo->query($categ);
    $requeteCount="select count(*) countCAT from categorie";
    $tabCount=$pdo->query($requeteCount);
    $tabC=$tabCount->fetch();
    $nbrCAT=$tabC['countCAT'];
 
?>
<!DOCTYPE html>
<html>

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>our categories</title>
    
    <LInk rel="stylesheet" href="css/bootstrap.min.css"></LInk>
    <link rel="stylesheet" href="assets/demo.css">
    <link rel="stylesheet" href="assets/navigation-icons.css">
    <link rel="stylesheet" href="assets/slicknav/slicknav.min.css">
    <link rel="stylesheet" href="assets/font-awesome.min.css">

    <style>
        {
            box-sizing: border-box;
        }
        /* Set additional styling options for the columns*/
        .column {
        float: left;
        width: 50%;
        }

        .row:after {
        content: "";
        display: table;
        clear: both;
        }
    </style>
</head>

<body>

<nav class="menu-navigation-icons">
        <a href="acceuil.php" class="menu-blue"><i class="glyphicon glyphicon-th-list"></i><span>Categories</span></a>
        <a href="products.php" class="menu-green"><i class="glyphicon glyphicon-shopping-cart"></i><span>les produits</span></a>
        <a href="utilisateur.php" class="menu-blue"><i class="glyphicon glyphicon-user"></i><span>les utilisateurs</span></a>
        <a href="fourniseur.php" class="menu-green"><i class="glyphicon glyphicon-usd"></i><span>Fournisseurs</span></a>
        <a href="approvisionnement.php" class="menu-blue"><i class="glyphicon glyphicon-credit-card"></i><span>approvisionnement</span></a>
        <a href="vente.php" class="menu-green"><i class="glyphicon glyphicon-stats"></i><span>Gains</span></a>
        <a href="password.php" class="menu-blue"><i class="glyphicon glyphicon-lock"></i><span>editer mot de pass</span></a>
        <a onclick="return confirm('etes vous sur de vouloir deconnecter ?')" href="index.php" class="menu-red"><i class="glyphicon glyphicon-log-out"></i><span>Deconnecter</span></a>

    </nav>

<br>
  

        <div class="row">
                <div class="panel panel-info ">
                        <div class="panel-heading" style="color: blue;font-size: 1.5em;padding: 1rem;text-align: center;text-transform: uppercase;">
                            <div class="row">
                                <div class="column">
                                    <strong>Categories :</strong>
                                </div>
                                <div class="column">
                                            <a href="formulairecategorie.php" style="color:white">
                                                        <button type="button" class="btn btn-success btn-lg" style="width:95%;">
                                                            <span class="glyphicon glyphicon-plus" style="color:white"></span>
                                                            Ajouter
                                                        </button>
                                            </a>
                                </div>
                            </div>
                        </div>
                        <div class="panel-body">
                            <table class="table table-striped table-bordered">
                                <thead>
                                
                                </thead>
                                <tbody>
                                    <style>
                                        tbody {
                                                font-weight: bolder
                                            }
                                        </style>
                                        <?php if($nbrCAT==3){ ?>
                                            <tr style="text-align:center;">
                                            <?php while($categorie=$resultat->fetch()){ ?>
                                                <td> <a href="products.php?idCAT=<?php echo $categorie['idCAT']?>">
                                                        <img src="images/<?php echo $categorie['pic']?>">
                                                    </a>
                                                    <br>
                                                    <div class="caption">  
                                                        <p id="autoResize"><?php echo $categorie['lib']."s"?>(<?php echo $categorie['quatite']." unites"?>)</p>
                                                        <a href="updatecategorie.php?idCAT=<?php echo $categorie['idCAT']?>" style="color:white">
                                                                        <button type="button" class="btn btn-success btn-lg" style="width:40%;">
                                                                            <span class="glyphicon glyphicon-edit" style="color:white"></span>
                                                                            Modifier
                                                                        </button>
                                                                    </a> 
                                                                    &nbsp 
                                                                <a onclick="return confirm('etes vous sur de vouloir supprimer CETTE CATEGORIE ?')" href="suppressioncategorie.php?idCAT=<?php echo $categorie['idCAT'] ?>">     
                                                                    <button class="btn btn-success btn-lg" style="width:20%;" >
                                                                        <span class="glyphicon glyphicon-trash" style="color:white"></span>
                                                                    </button>
                                                                </a>
                                                    </div>
                                                </td> 
                                                    
                                                <?php    }?>    
                                            <?php } else if($nbrCAT >3) {?> 
                                                <?php while($categorie=$resultat->fetch()){ ?>
                                                    
                                                    <tr style="text-align:center;">
                                                            <td> 
                                                                <a href="products.php?idCAT=<?php echo $categorie['idCAT']?>">
                                                                    <img src="images/<?php echo $categorie['pic']?>">
                                                                </a>
                                                                <br>
                                                                <div class="caption">  
                                                                    <p id="autoResize"><?php echo $categorie['lib']."s"?>(<?php echo $categorie['quatite']." unites"?>)</p>
                                                                </div> 
                                                            </td>
                                                            <td>    
                                                                <a href="updatecategorie.php?idCAT=<?php echo $categorie['idCAT']?>" style="color:white">
                                                                    <button type="button" class="btn btn-success btn-lg" style="width:40%;">
                                                                        <span class="glyphicon glyphicon-edit" style="color:white"></span>
                                                                            Modifier
                                                                    </button>
                                                                </a> 
                                                                &nbsp 
                                                                <a onclick="return confirm('etes vous sur de vouloir supprimer CETTE CATEGORIE ?')" href="suppressioncategorie.php?idCAT=<?php echo $categorie['idCAT'] ?>">     
                                                                    <button class="btn btn-success btn-lg" style="width:10%;" >
                                                                        <span class="glyphicon glyphicon-trash" style="color:white"></span>
                                                                    </button>
                                                                </a>
                                                                 
                                                            </td>
                                                        
                                                    </tr>
                                                <?php    }?>
                                            
                                                
                                         <?php  } else { ?>
                                            <tr>
                                                <td>
                                                    Aucune résultat
                                                </td>
                                            </tr>
                                        <?php } ?> 
                           

                                        
                                        
                                
                                </tbody>
                            
                            </table>
                            
                        </div>
                </div>
            
        </div>                              



        
           <br><br> <br><br><br><br>
           <footer class="footer"> 
               <div class="container">
               <center>
                  
               </center>
               </div>
           </footer>

<script src="assets/slicknav/jquery.slicknav.min.js"></script>
<script>
    $(function(){
        $('.menu-navigation-icons').slicknav();
    });
</script>

</body>

</html>
