<?php
session_start();
    
if(!isset($_SESSION['user'])) {
    header('location:index.php');
    exit();
}
    require_once("connexion.php");
    $resu="SELECT idVent,login,libelle,prixAchat,dateShop ,quanti
            FROM `vente`,produit,utilisateur 
            WHERE vente.idUS=utilisateur.iduser 
            and vente.idProduit=produit.idPRO";

   $sum=0;
    $resultatFi=$pdo->query($resu);
   



    $requeteCount="select count(*) countF from vente ";
    $filCount=$pdo->query($requeteCount);
    $tabCount=$filCount->fetch();
    $nbrSTAG=$tabCount['countF'];
?>
<!DOCTYPE html>
<html>

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>les gains</title>
<LInk rel="stylesheet" href="css/bootstrap.min.css"></LInk>
    <link rel="stylesheet" href="assets/demo.css">
    <link rel="stylesheet" href="assets/navigation-icons.css">
    <link rel="stylesheet" href="assets/slicknav/slicknav.min.css">

     
    <link rel="stylesheet" href="assets/font-awesome.min.css">

    <style>
    {
        box-sizing: border-box;
    }
    /* Set additional styling options for the columns*/
    .column {
    float: left;
    width: 50%;
    }

    .row:after {
    content: "";
    display: table;
    clear: both;
    }
    </style>
</head>

<body>


<nav class="menu-navigation-icons">
        <a href="acceuil.php" class="menu-blue"><i class="glyphicon glyphicon-th-list"></i><span>Categories</span></a>
        <a href="products.php" class="menu-green"><i class="glyphicon glyphicon-shopping-cart"></i><span>les produits</span></a>
        <a href="utilisateur.php" class="menu-blue"><i class="glyphicon glyphicon-user"></i><span>les utilisateurs</span></a>
        <a href="fourniseur.php" class="menu-green"><i class="glyphicon glyphicon-usd"></i><span>Fournisseurs</span></a>
        <a href="approvisionnement.php" class="menu-blue"><i class="glyphicon glyphicon-credit-card"></i><span>approvisionnement</span></a>
        <a href="vente.php" class="menu-green"><i class="glyphicon glyphicon-stats"></i><span>Gains</span></a>
        <a href="password.php" class="menu-blue"><i class="glyphicon glyphicon-lock"></i><span>editer mot de pass</span></a>
        <a onclick="return confirm('etes vous sur de vouloir deconnecter ?')" href="index.php" class="menu-red"><i class="glyphicon glyphicon-log-out"></i><span>Deconnecter</span></a>

    </nav>


<br>
    <div class="row">     
        <div>
            <div class="panel panel-info ">
                    <div class="panel-heading">
                      
                               
                    <div class="panel-body">
                        <table class="table table-striped table-bordered">
                            <thead>
                            <tr class="success">
                                    <th>numero</th><th>utilisateur</th><th>produit</th><th>Prix </th><th>quantite</th>
                                    <th>date</th>
                            
                                    </tr>
                            </thead>
                            <tbody>
                                <style>
                                    tbody {
                                            font-weight: bolder;
                                            background-color: grey;
                                        }
                                    </style>
                                
                                    <?php while($utilisateur=$resultatFi->fetch()){ ?>
                                        <?php $prix=$utilisateur['prixAchat'];$quantite=$utilisateur['quanti'];?>
                                    <tr class="success">
                                    <td><?php echo $utilisateur['idVent'] ?></td>
                                    <td><?php echo $utilisateur['login'] ?></td>
                                        <td><?php echo $utilisateur['libelle'] ?></td>
                                        <td> <?php echo $prix." dhs";$sum=$sum+$prix*$quantite;?> </td> 
                                         <td>  <?php echo"x". $quantite?>    
                                    </td>
                                        <td>  <?php echo $utilisateur['dateShop']?>    
                                         </td>
                                       
                                        
                                        
                                    </tr>
                                <?php } ?>
                                    
                               
                            </tbody>
                            <div class="row">
                                 <div class="column">
                                    </div>
                                    <div class="column" style="font-size: 1.5em;padding: 1rem;text-align: center;text-transform: uppercase;">
                                        <strong>somme : <?php echo $sum ?> dhs </strong>
                                    </div>
                                    
                            </div>
                        </table>
            </div>
        </div>
 

       


           <br><br> <br><br><br><br>
           <footer class="footer"> 
               <div class="container">
               <center>
                  
               </center>
               </div>
           </footer>

       
<script src="assets/slicknav/jquery.slicknav.min.js"></script>
<script>
    $(function(){
        $('.menu-navigation-icons').slicknav();
    });
</script>

</body>

</html>
