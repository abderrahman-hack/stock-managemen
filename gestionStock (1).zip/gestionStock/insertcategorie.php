<?php
session_start();
    
if(!isset($_SESSION['user'])) {
    header('location:index.php');
    exit();
}
    require_once("connexion.php");
    $id=isset($_POST['idCAT'])?$_POST['idCAT']:null;
   
    //$pic=isset($_POST['pic'])?$_POST['pic']:null;
    $lib=isset($_POST['lib'])?$_POST['lib']:null;

    
    $nom_photo= $_FILES['pic']['name'];
    $image_tmp=$_FILES['pic']['tmp_name'];
    move_uploaded_file($image_tmp,'images/'.$nom_photo);
   
     $requete="insert into categorie(lib,pic)
    values(?,?)";
    $params=array($lib,$nom_photo);

    $resultat=$pdo->prepare($requete);
    $etat = $resultat->execute($params);
    
    header('location:acceuil.php');

?>