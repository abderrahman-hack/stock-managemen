<?php
session_start();
    
if(!isset($_SESSION['user'])) {
    header('location:index.php');
    exit();
}
    require_once("connexion.php");
    $nom=isset($_POST['nomFourn'])?$_POST['nomFourn']:null;
    $email=isset($_POST['emailFourn'])?$_POST['emailFourn']:null;
    $adresse=isset($_POST['adresseFourn'])?$_POST['adresseFourn']:"V";
    $num=isset($_POST['numTeleFourn'])?$_POST['numTeleFourn']:null;
    
   $requete="insert into fournisseur(nomFourn,emailFourn,adresseFourn,numTeleFourn)
    values(?,?,?,?)";
    $params=array($nom,$email,$adresse,$num);

    $resultat=$pdo->prepare($requete);
    $etatx = $resultat->execute($params);
  
   header('location:fourniseur.php');


?>