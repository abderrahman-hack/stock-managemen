<?php
session_start();
    
if(!isset($_SESSION['user'])) {
    header('location:index.php');
    exit();
}
    require_once("connexion.php");

     
    $iduser=isset($_GET['iduser'])?$_GET['iduser']:null ;
  

    $result="select * from utilisateur,etat where iduser=$iduser";
    $etat="select * from etat";
    $resultat=$pdo->query($etat);

    $resultats=$pdo->query($result);
  
    $user=$resultats->fetch();

    $login=$user['login'];
    $email=$user['email'];
    $role=$user['role'];
    $etat=$user['etat'];
    $pwd=$user['pwd'];
    $adresse=$user['adresse'];
    $numtele=$user['numTele'];
    
    ?>

<!DOCTYPE HTML>
<HTML>
    <Head>
        <meta charset="utf-8">
        <title>editer utilisateur</title>
        <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
         <link rel="stylesheet" type="text/css" href="css/style.css">

    </Head>
    <body>
      
       <div class="container">
            
            <div class="panel panel-primary margetop">
                <div class="panel-heading">Editer</div>
                <div class="panel-body">
                    <form method="post" action="editerutilisateur.php?" class="form">
                        <!-- ............ -->
                        <div class="form-row">
                            <div class="form-group col-md-6">
                                <label for="iduser">id : <?php echo $iduser ?></label>
                                <input type="hidden" name="iduser" class="form-control" value="<?php echo $iduser ?>">
                        
                            </div>
                            <div class="form-group col-md-6">
                            <label for="login"> login </label>
                                <input type="text" name="login" class="form-control" value="<?php echo $login ?>"/>
                             </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group col-md-6">
                                <label for="role">role :</label>
                               <input type="text" name="role" class="form-control" value="<?php echo $role ?>"/>
                           
                            </div>
                            <div class="form-group col-md-6">
                                
                            <label for="email">email</label>
                                <input type="text" name="email" class="form-control" value="<?php echo $email ?>"/>
                           
                           
                              </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group col-md-6">
                            <label for="adresse"> Adresse</label>
                                <input type="text" name="adresse" class="form-control"  value="<?php echo $adresse ?>"/>
                            
                            </div>
                            <div class="form-group col-md-6">
                                <label for="numTele">numero</label>
                                <input type="text" name="numTele" class="form-control"  value="<?php echo $numtele ?>"/>
                           
                            </div>
                        </div
                       
            <!-- ............ -->  
                        <div class="form-row">
                            <div class="form-group col-md-6">
                            <label for="etat">etat</label>
                                <select name="etat" class="form-control" id="etat">
                                        <?php while($_ENT=$resultat->fetch()) { ?>
                                                <option value="<?php echo $_ENT['idEtat'] ?>" 
                                                <?php if($etat===$_ENT['idEtat']) echo "selected" ?>>
                                                    <?php echo $_ENT['status'] ?>
                                                </option>
                                        <?php }?>
                                </select>
                            </div>
                            <div class="form-group col-md-6">
                                <button type="submit" class="btn btn-success">
                                    <span class="glyphicon glyphicon-save"></span>
                                Enregistrer
                                </button>
                            </div>
                        </div>   
                          
                    </form>
                </div>
            </div>
        </div>
    </body>
</HTML>