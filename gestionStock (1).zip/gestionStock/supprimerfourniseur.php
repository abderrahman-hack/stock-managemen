<?php

    require_once("connexion.php");
    
    $id=isset($_GET['idFourn'])?$_GET['idFourn']:null;
  

    
    $requete="DELETE from fournisseur where idFourn=?";
    $params=array($id);
 
    $resultat=$pdo->prepare($requete);
    $ana=$resultat->execute($params);

    $impossible="select count(*) countfourn from fournisseur where idFourn =$id ";
    
    $resultatIMP=$pdo->query($impossible);
    $stag=$resultatIMP->fetch();
    $nbrfourn=$stag['countfourn'];

    if($nbrfourn==0){
        $params=array($id);
        $resultat=$pdo->prepare($requete);
        $ana=$resultat->execute($params);
        header('location:fourniseur.php');
    }else{
        $message="impossible de supprimer ce fournisseur :supprimer d'abords les produits ";
        header("location:message.php?msg=$message");
    }
    

?>