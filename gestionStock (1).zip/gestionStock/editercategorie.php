<?php
 session_start();
    
 if(!isset($_SESSION['user'])) {
     header('location:index.php');
     exit();
 }
require_once("connexion.php");

$id=isset($_POST['idCAT'])?$_POST['idCAT']:0;
$lib=isset($_POST['lib'])?$_POST['lib']:null;

$photo=isset($_FILES['pic']['name'])?$_FILES['pic']['name']:"";

$Temp=$_FILES['pic']['tmp_name'];

move_uploaded_file($Temp,"images/".$photo);

if(!empty($photo)){
    $requete="update categorie set 
    lib=? , pic=?
    where idCAT=?";
    $params=array($lib,$photo,$id);
}else{
    $requete="update categorie set 
    lib=?  
    where idCAT=?";
    $params=array($lib,$id);
}
   
$resultat=$pdo->prepare($requete);
$etat = $resultat->execute($params);

header('location:acceuil.php');



?>