<?php
session_start();
    
if(!isset($_SESSION['user'])) {
    header('location:index.php');
    exit();
}
    require_once("connexion.php");

    $etat="select idEtat,status from etat ";
   
    $resultF=$pdo->query($etat);
 
    
    
    ?>
<!DOCTYPE HTML>
<HTML>
    <Head>
        <meta charset="utf-8">
        <title>Ajouter utilisateur</title>
        <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
         <link rel="stylesheet" type="text/css" href="css/style.css">

    </Head>
    <body>
      
       <div class="container">
            
            <div class="panel panel-primary margetop">
                <div class="panel-heading">Ajouter</div>
                <div class="panel-body">
                    <form method="post" action="insertutilisateur.php" class="form">
                        <!-- ............ -->
                        <div class="form-row">
                            <div class="form-group col-md-6">
                            <label for="login"> login nom</label>
                                <input type="text" name="login" class="form-control" required/>
                            
                            </div>
                            <div class="form-group col-md-6">
                                <label for="email">email</label>
                                <input type="text" name="email" class="form-control" required/>
                           
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group col-md-6">
                                <label for="role">role :</label>
                                <div class="radio">
                                    <label><input type="radio" name="role" value="Admin" checked/> admin </label>
                                    <label><input type="radio" name="role" value="Visiteur"/> visiteur </label>
                                </div>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="etat">etat :</label>
                                <select name="etat" class="form-control" id="etat">
                                        <?php 
                                            while($_etat=$resultF->fetch()){ ?>
                                                <option value="<?php echo $_etat['idEtat'] ?>" 
                                                <?php if($etat===$_etat['idEtat']) echo "selected" ?>>
                                                <?php echo $_etat['status'] ?>
                                                </option>
                                        <?php }?>


                                </select>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group col-md-6">
                            <label for="adresse"> Adresse</label>
                                <input type="text" name="adresse" class="form-control" required/>
                            
                            </div>
                            <div class="form-group col-md-6">
                                <label for="numTele">numero</label>
                                <input type="text" name="numTele" class="form-control" required/>
                           
                            </div>
                        </div>
                       
            <!-- ............ -->  
                        <div class="form-row">
                            <div class="form-group col-md-6">
                                <label for="password">passsword :</label>
                                <input type="password" name="password" class="form-control" required id="id_password"/>
                                <input type="checkbox" onclick="myFunction()">Show Password
                                <script>
                                    function myFunction() {
                                            var x = document.getElementById("id_password");
                                            if (x.type === "password") {
                                                x.type = "text";
                                            } else {
                                                x.type = "password";
                                            }
                                            } 
                                </script>
                           </div>
                            <div class="form-group col-md-6">
                                <button type="submit" class="btn btn-success">
                                    <span class="glyphicon glyphicon-save"></span>
                                Enregistrer
                                </button>
                            </div>
                        </div>    
                    </form>
                </div>
            </div>
        </div>
    </body>
</HTML>