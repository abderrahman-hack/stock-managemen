

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";



------------------- Database: `test`---------------------------------
--login : admin
-- mdp : admin1234

-- --------------------------------------------------------

--
-- Table structure for table `approvisionnement`
--

CREATE TABLE `approvisionnement` (
  `id_achat` int(11) NOT NULL,
  `date_ach` date DEFAULT NULL,
  `id_fournisseur` int(11) DEFAULT NULL,
  `product` varchar(60) DEFAULT NULL,
  `quantite` int(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `approvisionnement`
--

INSERT INTO `approvisionnement` (`id_achat`, `date_ach`, `id_fournisseur`, `product`, `quantite`) VALUES
(2, '2021-12-30', 6, 'canon hf r800', 7);

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` int(11) NOT NULL,
  `username` varchar(20) NOT NULL,
  `PRO` int(11) NOT NULL,
  `quant` int(4) DEFAULT NULL,
  `status` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `categorie`
--

CREATE TABLE `categorie` (
  `idCAT` int(1) NOT NULL,
  `lib` varchar(20) DEFAULT NULL,
  `pic` varchar(60) DEFAULT NULL,
  `quatite` int(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `categorie`
--

INSERT INTO `categorie` (`idCAT`, `lib`, `pic`, `quatite`) VALUES
(1, 'macBook', 'laptops.jpg', 3),
(2, 'Iphone', 'iphones.jpg', 4),
(3, 'Canon', 'cameras.jpg', 5);

-- --------------------------------------------------------

--
-- Table structure for table `etat`
--

CREATE TABLE `etat` (
  `idEtat` int(2) NOT NULL,
  `status` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `etat`
--

INSERT INTO `etat` (`idEtat`, `status`) VALUES
(0, 'desactiver'),
(1, 'activer');

-- --------------------------------------------------------

--
-- Table structure for table `fournisseur`
--

CREATE TABLE `fournisseur` (
  `idFourn` int(11) NOT NULL,
  `nomFourn` varchar(70) DEFAULT NULL,
  `emailFourn` varchar(70) DEFAULT NULL,
  `adresseFourn` varchar(70) DEFAULT NULL,
  `numTeleFourn` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `fournisseur`
--

INSERT INTO `fournisseur` (`idFourn`, `nomFourn`, `emailFourn`, `adresseFourn`, `numTeleFourn`) VALUES
(1, 'abderraman ', 'fennane@gmail.com', 'EL MASSIRA', 663361329),
(4, 'anas', 'anas1@gmail.com', 'lamia', 612345678),
(6, 'Jamal', 'jamal@gmail.com', 'Casablaca-molay rachid', 687654321);

-- --------------------------------------------------------

--
-- Table structure for table `produit`
--

CREATE TABLE `produit` (
  `idPRO` int(2) NOT NULL,
  `reference` varchar(40) DEFAULT NULL,
  `libelle` varchar(40) DEFAULT NULL,
  `prixAchat` double DEFAULT NULL,
  `prixVente` double DEFAULT NULL,
  `photo` varchar(100) DEFAULT NULL,
  `cat` int(3) DEFAULT NULL,
  `fourn` int(5) DEFAULT NULL,
  `quantity` int(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `produit`
--

INSERT INTO `produit` (`idPRO`, `reference`, `libelle`, `prixAchat`, `prixVente`, `photo`, `cat`, `fourn`, `quantity`) VALUES
(5, 'A400', 'macbook touchbar', 12000, 10000, 'touchbarpro.jpg', 1, 4, 0),
(6, 'A6', 'IPHONE X', 9000, 8300.9, 'iphonex.jpg', 2, 4, 7),
(7, 'A7', 'IPHONE 12 PRO ', 9700, 8500.9, 'iphone12pro.jpg', 2, 4, 5),
(8, 'A8', 'IPHONE 12 PRO MAX', 9900, 8900.9, 'iphone12promax.jpg', 2, 4, 3),
(9, 'A9', 'IPHONE 13', 12000, 10000.9, 'iphone13.jpg', 2, 4, 4),
(10, 'A10', 'CANON EOS 30D', 9000, 8300.9, 'canon30d.jpg', 3, 4, 2),
(11, 'A11', 'CANON EOS 300D', 9400, 8300.9, 'canon300d.jpg', 3, 4, 4),
(12, 'A12', 'CANON EOS 7D MARK I', 9750, 8600.9, 'canonmark1.jpg', 3, 4, 5),
(32, 'A13', 'canon EOS 7D MARK II', 10300, 9000, 'canonmark2.jpg', 3, 1, 2),
(37, 'A16', 'MACBOOK PRO 16', 12000, 11000, 'macbookrpo16.jpg', 1, 1, 2),
(38, 'A212', 'MACBOOK PRO 13', 123, 234, 'macbookrpo13.jpg', 1, 4, 4),
(45, 'B22', 'canon hf r800', 8900, 7000, 'canon_hf_r800.jpg', 3, 6, 7);

-- --------------------------------------------------------

--
-- Table structure for table `utilisateur`
--

CREATE TABLE `utilisateur` (
  `iduser` int(4) NOT NULL,
  `login` varchar(50) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `role` varchar(50) DEFAULT NULL,
  `etat` int(1) DEFAULT NULL,
  `pwd` varchar(255) DEFAULT NULL,
  `adresse` varchar(70) DEFAULT NULL,
  `numTele` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `utilisateur`
--

INSERT INTO `utilisateur` (`iduser`, `login`, `email`, `role`, `etat`, `pwd`, `adresse`, `numTele`) VALUES
(1, 'admin', 'admin@gmail.com', 'ADMIN', 1, 'c93ccd78b2076528346216b3b2f701e6', 'HAY MASSIRA SAFI', 612345678),
(2, 'user1', 'user1@gmail.com', 'VISITEUR', 0, '16721ca310944f51ce47751ab30b726b', 'HAY LAMIA SAFI', 612245678),
(3, 'user2', 'user2@gmail.com', 'VISITEUR', 1, 'b2adfbf49b5a8facf2ac499630ea96bd', NULL, NULL),
(11, 'fenane', 'fennane@gmail.com', 'Visiteur', 1, NULL, 'hay rahma', 663361329),
(12, 'abdou', 'abdou@gmail.com', 'Visiteur', 1, '0188925ca0212c90c48c7f952b9eadcc', 'hay ra7ma', 6366666);

-- --------------------------------------------------------

--
-- Table structure for table `vente`
--

CREATE TABLE `vente` (
  `idVent` int(3) NOT NULL,
  `idProduit` int(4) DEFAULT NULL,
  `idUS` int(4) DEFAULT NULL,
  `dateShop` date DEFAULT NULL,
  `quanti` int(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `vente`
--

INSERT INTO `vente` (`idVent`, `idProduit`, `idUS`, `dateShop`, `quanti`) VALUES
(126, 5, 12, '2021-12-30', 2);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `approvisionnement`
--
ALTER TABLE `approvisionnement`
  ADD PRIMARY KEY (`id_achat`),
  ADD KEY `fk_id_fourn` (`id_fournisseur`);

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`),
  ADD KEY `pfh` (`PRO`);

--
-- Indexes for table `categorie`
--
ALTER TABLE `categorie`
  ADD PRIMARY KEY (`idCAT`);

--
-- Indexes for table `etat`
--
ALTER TABLE `etat`
  ADD PRIMARY KEY (`idEtat`);

--
-- Indexes for table `fournisseur`
--
ALTER TABLE `fournisseur`
  ADD PRIMARY KEY (`idFourn`);

--
-- Indexes for table `produit`
--
ALTER TABLE `produit`
  ADD PRIMARY KEY (`idPRO`),
  ADD KEY `idCAT` (`cat`),
  ADD KEY `pfl` (`fourn`);

--
-- Indexes for table `utilisateur`
--
ALTER TABLE `utilisateur`
  ADD PRIMARY KEY (`iduser`),
  ADD KEY `etat` (`etat`);

--
-- Indexes for table `vente`
--
ALTER TABLE `vente`
  ADD PRIMARY KEY (`idVent`),
  ADD KEY `pfs` (`idProduit`),
  ADD KEY `gg` (`idUS`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `approvisionnement`
--
ALTER TABLE `approvisionnement`
  MODIFY `id_achat` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=102;

--
-- AUTO_INCREMENT for table `categorie`
--
ALTER TABLE `categorie`
  MODIFY `idCAT` int(1) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `fournisseur`
--
ALTER TABLE `fournisseur`
  MODIFY `idFourn` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `produit`
--
ALTER TABLE `produit`
  MODIFY `idPRO` int(2) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;

--
-- AUTO_INCREMENT for table `utilisateur`
--
ALTER TABLE `utilisateur`
  MODIFY `iduser` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `vente`
--
ALTER TABLE `vente`
  MODIFY `idVent` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=127;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `cart`
--
ALTER TABLE `cart`
  ADD CONSTRAINT `pfh` FOREIGN KEY (`PRO`) REFERENCES `produit` (`idPRO`) ON DELETE CASCADE;

--
-- Constraints for table `produit`
--
ALTER TABLE `produit`
  ADD CONSTRAINT `pf` FOREIGN KEY (`cat`) REFERENCES `categorie` (`idCAT`),
  ADD CONSTRAINT `pfl` FOREIGN KEY (`fourn`) REFERENCES `fournisseur` (`idFourn`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
