<?php
session_start();
    
if(!isset($_SESSION['user'])) {
    header('location:index.php');
    exit();
}
    require_once("connexion.php");
    $id=isset($_POST['iduser'])?$_POST['iduser']:null;
    $login=isset($_POST['login'])?$_POST['login']:null;
    $email=isset($_POST['email'])?$_POST['email']:null;
    $role=isset($_POST['role'])?$_POST['role']:"VISITEUR";
    $etat=isset($_POST['etat'])?$_POST['etat']:null;
    $adresse=isset($_POST['adresse'])?$_POST['adresse']:null;
    $numTele=isset($_POST['numTele'])?$_POST['numTele']:null;
    $pwd=isset($_POST['password'])?$_POST['password']:null;

    $requete="update utilisateur
    set login=?,email=?,role=?,etat=?,pwd=?,adresse=?,numTele=?
    where iduser=?";
    $params=array($login,$email,$role,$etat,$pwd,$adresse,$numTele,$id);
    $resultat=$pdo->prepare($requete);
    $etat=$resultat->execute($params);
    var_dump($etat);
   header('location:utilisateur.php');
    //echo '<script>alert("bien edite !")</script>';



?>