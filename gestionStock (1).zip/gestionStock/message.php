<?php
    session_start();
    
    if(!isset($_SESSION['user'])) {
        header('location:index.php');
        exit();
    }
    $message=isset($_GET['msg'])?$_GET['msg']:"ereur";
 
?>
<! DOCTYPE HTML>
<HTML>
    <Head>
        <meta charset="utf-8">
        <title>message d'erreur</title>
        <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
        <link rel="stylesheet" type="text/css" href="css/style.css">
         <style>
            body{
                background-image: url(../images/Dark.jpg);
               -webkit-transition: all 1s ease;
                   -moz-transition: all 1s ease;
                        -o-transition: all 1s ease;
                     -ms-transition: all 1s ease;
                            transition: all 1s ease; 
        

            }
        </style>
    </Head>
    <body>
        <div class="container ">
            <div class="panel panel-success margetop">
                <div class="panel-heading">ERREUR</div>
                <div class="panel-body">
                    <h3 style="text-align:center;color:red;font-weight: bold;"><?php echo $message ?></h3>
                    
                
                        <a href="fourniseur.php" style="color:white">
                            <button class="btn btn-success" style="margin:auto;display:block">
                                <span class="glyphicon glyphicon-backward" style="color:white"></span> retour
                        </button></a>
                

                    

                </div>
            </div>
            
           
                </div>
            
        
    </body>
</HTML>