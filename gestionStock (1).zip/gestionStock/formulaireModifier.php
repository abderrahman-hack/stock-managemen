<?php
session_start();
    
if(!isset($_SESSION['user'])) {
    header('location:index.php');
    exit();
}
    require_once("connexion.php");

     
    $idPRO=isset($_GET['idPRO'])?$_GET['idPRO']:null ;
    $idfourn=isset($_GET['idFourn'])?$_GET['idFourn']:null ;
  

    $result="select * from produit,categorie where idPRO=$idPRO";
    $cat="select * from categorie ";
    $fourn="select * from fournisseur ";

    $resultats=$pdo->query($result);
    $prod=$resultats->fetch();
    $ref=$prod['reference'];
    $lib=$prod['libelle'];
    $prixA=$prod['prixAchat'];
    $prixV=$prod['prixVente'];
    $photo=$prod['photo'];
    $idCAt=$prod['cat'];
    $idfourn=$prod['fourn'];
    $quant=$prod['quantity'];

    $resultF=$pdo->query($cat);
    $re=$pdo->query($fourn);
    
    
    ?>
<!DOCTYPE HTML>
<HTML>
    <Head>
        <meta charset="utf-8">
        <title>Editer produit</title>
        <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
         <link rel="stylesheet" type="text/css" href="css/style.css">

    </Head>
    <body>
      
       <div class="container">
            
            <div class="panel panel-primary margetop">
                <div class="panel-heading">modifier un produit</div>
                <div class="panel-body">
                    <form method="POST" action="editerproduit.php" class="form" enctype="multipart/form-data">
                   
                        <div class="form-group">
                             <label for="idPRO">id :<?php echo $idPRO ?> </label>
                             <input type="hidden" name="idPRO" class="form-control" value="<?php echo $idPRO ?>">
                        
                        </div>
                        <div class="form-row">
                              <div class="form-group col-md-6">
                                <label for="libelle">libelle :</label>
                                <input type="text" name="libelle" placeholder="libelle" class="form-control"  value="<?php echo $lib?>" >
                              </div>
                              <div class="form-group col-md-6">
                                <label for="reference"> reference </label>
                                <input type="text" name="reference" placeholder="reference" class="form-control"  value="<?php echo $ref?>">
                              </div>
                        </div>
                          
                        <div class="form-row">
                            <div class="form-group col-md-6">
                               <label for="prixAchat">prix Achat :</label>
                                <input type="text" name="prixAchat" placeholder="prixAchat" class="form-control"  value="<?php echo $prixA?>">
                            </div>
                            <div class="form-group col-md-6">
                               <label for="prixVente">prix vente :</label>
                                <input type="text" name="prixVente" placeholder="prixVente" class="form-control"  value="<?php echo $prixV?>">
                            </div>
                        </div>
                          
                        <div class="form-row">
                            <div class="form-group col-md-6">
                            <label for="cat">categorie</label>
                                <select name="cat" class="form-control" id="cat">
                                        <?php while($_ENT=$resultF->fetch()) { ?>
                                                <option value="<?php echo $_ENT['idCAT'] ?>" 
                                                <?php if($idCAt===$_ENT['idCAT']) echo "selected" ?>>
                                                    <?php echo $_ENT['lib'] ?>
                                                </option>
                                        <?php }?>
                                </select>
                              </div>
                            <div class="form-group col-md-6">
                            <label for="idFourn">fournisseur</label>
                                <select name="idFourn" class="form-control" id="idFourn">
                                        <?php while($ENT=$re->fetch()) { ?>
                                                <option value="<?php echo $ENT['idFourn'] ?>" 
                                                <?php if($idfourn===$ENT['idFourn']) echo "selected" ?>>
                                                    <?php echo $ENT['nomFourn'] ?>
                                                </option>
                                        <?php }?>
                                </select>
                            </div>
                        </div>
                       
                        <div class="form-row">
                            <div class="form-group col-md-6">
                            <label for="photo">Photo :</label>
                                <input type="file" name="photo"/>
                           
                     
                            </div>
                            <div class="form-group col-md-6">
                            <label for="quantity">quantity :</label>
                                <input type="number" name="quantity" placeholder="quantity" class="form-control" min=1 max=10 value="<?php echo $quant?>">
                           
                            </div>

                        </div>
                       <button type="submit" class="btn btn-success">
                            <span class="glyphicon glyphicon-adjust"></span>
                            
                            Modifier
                            
                        </button>
                        
                    </form>
                    
                </div>
            </div>
        </div>
    </body>
</HTML>