<?php
session_start();
    
if(!isset($_SESSION['user'])) {
    header('location:index.php');
    exit();
}
    require_once("connexion.php");

  
    
    ?>
<!DOCTYPE HTML>
<HTML>
    <Head>
        <meta charset="utf-8">
        <title>Ajouter fournisseur</title>
        <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
         <link rel="stylesheet" type="text/css" href="css/style.css">

    </Head>
    <body>
      
       <div class="container">
            
            <div class="panel panel-primary margetop">
                <div class="panel-heading">Ajouter</div>
                <div class="panel-body">
                    <form method="post" action="insertfournisseur.php" class="form">
                        <!-- ............ -->
                        <div class="form-row">
                            <div class="form-group col-md-6">
                            <label for="nomFourn">Nom</label>
                                <input type="text" name="nomFourn" class="form-control" required/>
                            
                            </div>
                            <div class="form-group col-md-6">
                                <label for="emailFourn">Email</label>
                                <input type="text" name="emailFourn" class="form-control" required/>
                           
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group col-md-6">
                                <label for="adresseFourn">Adresse</label>
                                <input type="text" name="adresseFourn" class="form-control" required/>
                            </div>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="numTeleFourn">numero </label>
                                <input type="text" name="numTeleFourn" class="form-control" required/>
                            </div>
                        </div>
     
                        <div class="form-row">
                            <div class="form-group col-md-6">
                             <button type="submit" class="btn btn-success">
                                    <span class="glyphicon glyphicon-save"></span>
                                Enregistrer
                                </button>
                           </div>
                        </div>    
                    </form>
                </div>
            </div>
        </div>
    </body>
</HTML>