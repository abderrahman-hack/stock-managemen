<?php
session_start();
    
if(!isset($_SESSION['user'])) {
    header('location:index.php');
    exit();
}
    require_once("connexion.php");

  
    
    ?>
<!DOCTYPE HTML>
<HTML>
    <Head>
        <meta charset="utf-8">
        <title>Ajouter categorie</title>
        <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
         <link rel="stylesheet" type="text/css" href="css/style.css">

    </Head>
    <body>
      
       <div class="container">
            
            <div class="panel panel-primary margetop">
                <div class="panel-heading">Ajouter</div>
                <div class="panel-body">
                    <form method="post" action="insertcategorie.php" class="form" enctype="multipart/form-data">
                        <!-- ............ -->
                        <div class="form-row">
                            <div class="form-group col-md-6">
                                <label for="lib">categorie</label>
                                <input type="text" name="lib" class="form-control" required/>
                            
                            </div>
                            <div class="form-group col-md-6">
                               <label for="pic">Photo :</label>
                                <input type="file" name="pic" class="form-control" />
                               
                            </div>
                        </div>
     
                        <div class="form-row">
                             <div class="form-group col-md-6">
                                
                            </div>
                            <div class="form-group col-md-6">
                             
                           </div><button type="submit" class="btn btn-success">
                                    <span class="glyphicon glyphicon-save"></span>
                                Enregistrer
                                </button>
                        </div>    
                    </form>
                </div>
            </div>
        </div>
    </body>
</HTML>