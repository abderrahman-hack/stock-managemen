<?php
session_start();
    
if(!isset($_SESSION['user'])) {
    header('location:index.php');
    exit();
}
    require_once("connexion.php");

     
    $id=isset($_GET['idCAT'])?$_GET['idCAT']:null ;
  

    $result="select * from categorie where idCAT=$id";

    $resultats=$pdo->query($result);
    $categ=$resultats->fetch();

    $idCAT=$categ['idCAT'];
    $LIB=$categ['lib'];
    $photo=$categ['pic'];
   
    ?>

<!DOCTYPE HTML>
<HTML>
    <Head>
        <meta charset="utf-8">
        <title>editer categorie</title>
        <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
         <link rel="stylesheet" type="text/css" href="css/style.css">

    </Head>
    <body>
      
       <div class="container">
            
            <div class="panel panel-primary margetop">
                <div class="panel-heading">Editer</div>
                <div class="panel-body">
                    <form method="post" action="editercategorie.php" class="form" enctype="multipart/form-data">
                        <!-- ............ -->
                        <div class="form-row">
                            <div class="form-group col-md-6">
                                <label for="idCAT">id : </label>
                                <input type="hidden" name="idCAT" class="form-control" value="<?php echo $idCAT ?>">
                        
                            </div>
                            <div class="form-group col-md-6">
                            <label for="lib"> libelle </label>
                                <input type="text" name="lib" class="form-control" value="<?php echo $LIB ?>"/>
                             </div>
                        </div>
                    
                      <div class="form-row">
                            <div class="form-group col-md-6">
                            <label for="pic">Photo :</label>
                                <input type="file" name="pic"/>
                           
                            </div>
                            <div class="form-group col-md-6">
                                <button type="submit" class="btn btn-success">
                                    <span class="glyphicon glyphicon-save"></span>
                                Enregistrer
                                </button>
                            </div>
                        </div>   
                          
                    </form>
                </div>
            </div>
        </div>
    </body>
</HTML>