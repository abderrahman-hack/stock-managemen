<?php
session_start();
    
if(!isset($_SESSION['user'])) {
    header('location:index.php');
    exit();
}
    require_once("connexion.php");
    $id=isset($_POST['idFourn'])?$_POST['idFourn']:0;
    $nom=isset($_POST['nomFourn'])?$_POST['nomFourn']:null;
    $email=isset($_POST['emailFourn'])?$_POST['emailFourn']:null;
    $adresse=isset($_POST['adresseFourn'])?$_POST['adresseFourn']:null;
    $numTele=isset($_POST['numTeleFourn'])?$_POST['numTeleFourn']:null;
   
    $requete="update fournisseur
    set nomFourn=?,emailFourn=?,adresseFourn=?,numTeleFourn=?
    where idFourn=?";
    $params=array($nom,$email,$adresse,$numTele,$id);
   $resultat=$pdo->prepare($requete);
    $etat=$resultat->execute($params);
    header('location:fourniseur.php');
    

?>