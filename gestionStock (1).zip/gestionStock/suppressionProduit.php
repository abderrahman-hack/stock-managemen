<?php
session_start();
    
if(!isset($_SESSION['user'])) {
    header('location:index.php');
    exit();
}
    require_once("connexion.php");
    
    $id=isset($_GET['idPRO'])?$_GET['idPRO']:null;
    $cat=isset($_GET['cat'])?$_GET['cat']:null;
   echo $cat;


    
    $requete="DELETE from produit where idPRO=?";
    $params=array($id);
 
    $resultat=$pdo->prepare($requete);
    $ana=$resultat->execute($params);
var_dump($params);

$categorie="update categorie
     set quatite=(select count(*) from produit where produit.cat='$cat')
     where idCAT='$cat' ";
    $result=$pdo->prepare($categorie);
    $etat = $result->execute();
    var_dump($params);

    $requet="select idCAT from categorie";
    $resu=$pdo->query($requet);
    
    while($at = $resu->fetch()){
        $cate=$at['idCAT'];
        $categorie="update categorie
        set quatite=(select count(*) from produit where produit.cat='$cate')
        where idCAT='$cate' ";
        $result=$pdo->prepare($categorie);
        $eta = $result->execute();
    }
header('location:products.php');


?>