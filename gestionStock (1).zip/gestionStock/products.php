<?php
    session_start();
    
    if(!isset($_SESSION['user'])) {
        header('location:index.php');
        exit();
    }
    require_once("connexion.php");

    $id=isset($_GET['idCAT'])?$_GET['idCAT']:'all';
    $result="select * from produit ";
    $resultats=$pdo->query($result);
    
    $requeteCount="select count(*) countF from produit";
    $fourn="select idFourn,nomFourn from fournisseur ";
    $re=$pdo->query($fourn);
    $fournisseur=$re->fetch();
    $idFourn=$fournisseur['idFourn'];
    
$requete="select idPRO,libelle, cat,prixAchat,prixVente,photo,lib,quantity,nomFourn from categorie,fournisseur, produit
 where produit.fourn=fournisseur.idFourn and produit.cat=categorie.idCAT ";
$result="select idCAT,lib from categorie ";
    $where_requete = "";
    if($id=='all')
    {   
    $resultatF=$pdo->query($requete);
    }
    else if($id) {
        $where_requete .= " and produit.cat ='$id'";
        $requete .= $where_requete;
        $requeteCount .= " where produit.cat ='$id' ";
    }

    $filCount=$pdo->query($requeteCount);
    $tabCount=$filCount->fetch();
    $nbrpro=$tabCount['countF'];

    $resultatF=$pdo->query($requete);
    $resultF=$pdo->query($result);
    /*$libelle=$produit['libelle'];
    $prixAchat=$produit['prixAchat'];
    $photo=$produit['photo'];*/
    $re="select iduser,login from utilisateur";
    $et=$pdo->query($re);

?>

<!DOCTYPE html>
<html>
    <head>
        <LInk rel="stylesheet" href="css/bootstrap.min.css"></LInk>
        <link rel="stylesheet" href="assets/demo.css">
        <link rel="stylesheet" href="assets/navigation-icons.css">
        <link rel="stylesheet" href="assets/slicknav/slicknav.min.css">
        
        <link rel="stylesheet" href="assets/font-awesome.min.css">


        <style>
            {
                box-sizing: border-box;
            }
            /* Set additional styling options for the columns*/
            .column {
            float: left;
            width: 50%;
            }

            .row:after {
            content: "";
            display: table;
            clear: both;
            }
        </style>
            <link rel="shortcut icon" href="img/lifestyleStore.png" />
        <title>product </title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <!-- latest compiled and minified CSS -->
        <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">
        <!-- jquery library -->
        <script type="text/javascript" src="js/jquery-3.6.0.min.js"></script>
        <!-- Latest compiled and minified javascript -->
        <script type="text/javascript" src="js/bootstrap.min.js"></script>
        <!-- External CSS -->
        <link rel="stylesheet" href="css/style (4).css" type="text/css">
        <style>
            .column {
                float: left;
                width: 33.33%;
                }
        </style>
    </head>

    <nav class="menu-navigation-icons">
        <a href="acceuil.php" class="menu-blue"><i class="glyphicon glyphicon-th-list"></i><span>Categories</span></a>
        <a href="products.php" class="menu-green"><i class="glyphicon glyphicon-shopping-cart"></i><span>les produits</span></a>
        <a href="utilisateur.php" class="menu-blue"><i class="glyphicon glyphicon-user"></i><span>les utilisateurs</span></a>
        <a href="fourniseur.php" class="menu-green"><i class="glyphicon glyphicon-usd"></i><span>Fournisseurs</span></a>
        <a href="approvisionnement.php" class="menu-blue"><i class="glyphicon glyphicon-credit-card"></i><span>approvisionnement</span></a>
        <a href="vente.php" class="menu-green"><i class="glyphicon glyphicon-stats"></i><span>Gains</span></a>
        <a href="password.php" class="menu-blue"><i class="glyphicon glyphicon-lock"></i><span>editer mot de pass</span></a>
        <a onclick="return confirm('etes vous sur de vouloir deconnecter ?')" href="index.php" class="menu-red"><i class="glyphicon glyphicon-log-out"></i><span>Deconnecter</span></a>

    </nav>


        <div>
           
          <br>
        </div>


        <div class="row">     
            <div>
                <div class="panel panel-info ">
                    <div class="panel-heading" >
                    <div class="row">
                        <div class="col-6 col-md-4"></div>
                        <div class="col-6 col-md-4"  style="font-size: 1.5em;padding: 1rem;text-align: center;text-transform: uppercase;">
                                    <strong> Produits :(<?php echo $nbrpro ?>)produits:</strong>
                                </div>
                        <div class="col-6 col-md-4"></div>
                    </div>
                        <style>
                            .column {
                                float: left;
                                width: 25%;
                                }

                                /* Clear floats after the columns */
                                .row:after {
                                content: "";
                                display: table;
                                clear: both;
                                }
                        </style>
                        <div class="container">
                            <div class="row"> 
                                <form method="get" action="products.php" class="form-inline">
                                    <div class="col-6 col-md-4">
                                        <select name="idCAT" class="form-control" id="idCAt" onchange="this.form.submit()" style="width:95%">
                                            <option value="all" <?php if($id===null) echo "selected" ?>>tous les produits</option>
                                                <?php while($categorie=$resultF->fetch()){ ?>
                                                    <option value="<?php echo $categorie['idCAT'] ?>" 
                                                        <?php if($id===$categorie['idCAT']) echo "selected" ?>>
                                                            <?php echo $categorie['lib'] ?>
                                                    </option>
                                                <?php }?>
                                        </select>
                                    </div>  
                                </form>   
                                    <div class="col-6 col-md-4">
                                        <a href="formulaireAjouter.php" style="color:white">
                                            <button type="button" class="btn btn-success btn-lg" style="width:95%;">
                                                <span class="glyphicon glyphicon-plus" style="color:white"></span>
                                                    Ajouter
                                            </button>
                                    </a>
                                </div>
                            </div>
                        </div>
                        <div class="panel-body">
                            <table class="table table-striped table-bordered">
                                <thead>
                                    <tr class="success">
                                    <th>Id</th><th></th><th></th><th>Prix de vente </th><th>Prix d'achat</th><th>quantite</th><th>Fournisseur</th><th>Action</th>
                            
                                    </tr>
                                </thead>
                                <tbody>
                                    <style>
                                        tbody {
                                                font-weight: bolder
                                            }
                                    </style>
                                        <?php while($produit=$resultatF->fetch()) { ?>
                                                <tr class="success">
                                                    <td><?php echo $produit['idPRO']?></td>
                                                <td>
                                                    <img src="images/<?php echo $produit['photo']?>">
                                                    </td> 
                                                    <td><?php echo $produit['libelle'] ?></td>
                                                    <td><?php echo $produit['prixAchat']. " DHS"?></td>
                                                    <td><?php echo $produit['prixVente']. " DHS"?></td>
                                                    <td><?php echo $produit['quantity'] ?></td>
                                                    <td><?php echo $produit['nomFourn'] ?></td>
                                                  <td>
                                                            <a href="formulaireModifier.php?idPRO=<?php echo $produit['idPRO']?>&idFourn=<?php echo $produit['fourn']?>" style="color:white">
                                                                        <button type="button" class="btn btn-success btn-lg" style="width:60%;">
                                                                            <span class="glyphicon glyphicon-edit" style="color:white"></span>
                                                                            Modifier
                                                                </button>
                                                            </a>
                                                        &nbsp 
                                                            <a onclick="return confirm('etes vous sur de vouloir supprimer CE PRODUIT ?')" href="suppressionProduit.php?idPRO=<?php echo $produit['idPRO'] ?>&cat=<?php echo $produit['cat'] ?>">     
                                                                <button class="btn btn-success btn-lg" style="width:30%;" >
                                                                    <span class="glyphicon glyphicon-trash" style="color:white"></span>
                                                                </button>
                                                            </a>
                                                            
                                                    </td> 
                                                   
                                                </tr>
                                            <?php  } ?>
                                </tbody>
                            </table>
                        </div>
                 </div>
            </div>                                   

        </div>

<script src="assets/slicknav/jquery.slicknav.min.js"></script>
<script>
    $(function(){
        $('.menu-navigation-icons').slicknav();
    });
</script>
    </body>
</html>
